package com.topsuntech.gUnit.gEU_taskFilter.log.dao;

import com.topsuntech.gOS.query.DBRegistry;
import com.topsuntech.gOS.query.DBWrapper;
import com.topsuntech.gOS.query.TSDBException;
import com.topsuntech.gUnit.gEU_taskFilter.log.entity.LogRecord;
import com.topsuntech.gUnit.gEU_taskFilter.log.entity.LogRecordContent;

public class LogRecordDao {
	private static DBWrapper dbWrapper = DBRegistry.getDBWrapper("gos");

	public static final int CONTENT_STR_LENGTH = 2000;

	public void save(LogRecord record) throws TSDBException {
		dbWrapper.insert(record);
	}

	public void saveContent(LogRecord record, StringBuffer contentBuf) throws TSDBException {
		int size = (int) Math.ceil(contentBuf.length() / (double) CONTENT_STR_LENGTH);
		for (int i = 0; i < size; i++) {
			LogRecordContent lContent = new LogRecordContent();
			lContent.setLogId(record.getId());
			int sInd = i * CONTENT_STR_LENGTH;
			int eInd = sInd + CONTENT_STR_LENGTH;
			if (eInd > contentBuf.length()) {
				eInd = contentBuf.length();
			}
			lContent.setContent(contentBuf.substring(sInd, eInd));
			dbWrapper.insert(lContent);
		}
	}
}
