package com.topsuntech.gUnit.gEU_taskFilter.log.entity;

import java.io.Serializable;
import java.util.Date;

public class LogRecord implements Serializable {

	private static final long serialVersionUID = -3429212254587177450L;

	private Long id;

	private Long funUrlId;

	private Long userId;

	private Integer userType;

	private String inetAddress;

	private Date accessTime;

	public Date getAccessTime() {
		return accessTime;
	}

	public void setAccessTime(Date accessTime) {
		this.accessTime = accessTime;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getFunUrlId() {
		return funUrlId;
	}

	public void setFunUrlId(Long funUrlId) {
		this.funUrlId = funUrlId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Integer getUserType() {
		return userType;
	}

	public void setUserType(Integer userType) {
		this.userType = userType;
	}

	public String getInetAddress() {
		return inetAddress;
	}

	public void setInetAddress(String inetAddress) {
		this.inetAddress = inetAddress;
	}

}
