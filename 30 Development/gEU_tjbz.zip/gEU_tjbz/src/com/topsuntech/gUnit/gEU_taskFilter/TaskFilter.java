package com.topsuntech.gUnit.gEU_taskFilter;

import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import com.topsuntech.gOS.logger.Logger;


public class TaskFilter implements Filter {

	protected String encoding = null;

	protected FilterConfig filterConfig = null;

	protected String taskCallableClassName = null;

	protected ExecutorService executorService = null;

	protected int threadNum = 3;

	public void init(FilterConfig filterConfig) throws ServletException {

		this.filterConfig = filterConfig;
		this.encoding = filterConfig.getInitParameter("encoding");

		taskCallableClassName = filterConfig.getInitParameter("taskCallable");
		if (taskCallableClassName == null) {
			throw new IllegalArgumentException("taskCallable is missing");
		}

		initExecutor(filterConfig);
	}

	protected void initExecutor(FilterConfig filterConfig) {
		String threadNumStr = filterConfig.getInitParameter("threadNum");
		try {
			if (threadNumStr != null) {
				threadNum = Integer.parseInt(threadNumStr);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		executorService = Executors.newFixedThreadPool(threadNum);
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		if (encoding != null) {
			request.setCharacterEncoding(encoding);
		}

		final TaskCallable taskCallable = createTaskCallable();
		try {
			taskCallable.synCall(request, filterConfig);
		} catch (Throwable e) {
			e.printStackTrace();
			Logger.error(e.getMessage(), e);
		}

		executorService.submit(new Runnable() {
			public void run() {
				taskCallable.asynCall();
			}
		});

		chain.doFilter(request, response);
	}

	protected TaskCallable createTaskCallable() throws ServletException {
		try {
			return (TaskCallable) Class.forName(taskCallableClassName).newInstance();
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServletException(e.getMessage());
		}
	}

	public void destroy() {
		encoding = null;
		filterConfig = null;
		taskCallableClassName = null;
		try {
			executorService.shutdownNow();
		} catch (Exception e) {
		}

	}

}
