package com.topsuntech.gUnit.gEU_taskFilter.log.entity;

import java.io.Serializable;

public class LogRecordContent implements Serializable {

	private static final long serialVersionUID = 69731276695046000L;

	private Long id;

	private Long logId;

	private String content;

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getLogId() {
		return logId;
	}

	public void setLogId(Long logId) {
		this.logId = logId;
	}

}
