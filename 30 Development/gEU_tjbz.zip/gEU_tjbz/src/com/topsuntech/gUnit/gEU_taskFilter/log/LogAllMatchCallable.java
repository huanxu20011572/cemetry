package com.topsuntech.gUnit.gEU_taskFilter.log;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.FilterConfig;
import javax.servlet.ServletRequest;

import com.topsuntech.gOS.query.TSDBException;
import com.topsuntech.gUnit.gEU_taskFilter.log.dao.LogRecordDao;
import com.topsuntech.gUnit.gEU_taskFilter.log.entity.AppFunUrl;
import com.topsuntech.gUnit.gEU_taskFilter.log.entity.LogRecord;

public class LogAllMatchCallable implements MatchCallable {
	private Map paramMap;

	public void synCall(ServletRequest request, FilterConfig filterConfig) {
		paramMap = new HashMap(request.getParameterMap());
	}

	public void asynCall(AppFunUrl appFunUrl, LogRecord record) {
		Integer cType = appFunUrl.getContentType();
		if (paramMap != null && cType != null && cType.intValue() == 1) {
			StringBuffer sBuf = new StringBuffer();
			for (Iterator iter = paramMap.entrySet().iterator(); iter.hasNext();) {
				Map.Entry me = (Map.Entry) iter.next();
				if (me.getValue() instanceof String[]) {
					String[] value = (String[]) me.getValue();
					for (int i = 0; i < value.length;) {
						sBuf.append(me.getKey()).append("=").append(value[i]);
						if (++i < value.length) {
							sBuf.append("&");
						}
					}
				} else {
					sBuf.append(me.getKey()).append("=").append(me.getValue());
				}
				if (iter.hasNext()) {
					sBuf.append("&");
				}
			}
			try {
				new LogRecordDao().saveContent(record, sBuf);
			} catch (TSDBException e) {
				e.printStackTrace();
			}

			paramMap.clear();
			paramMap = null;
		}
	}

}
