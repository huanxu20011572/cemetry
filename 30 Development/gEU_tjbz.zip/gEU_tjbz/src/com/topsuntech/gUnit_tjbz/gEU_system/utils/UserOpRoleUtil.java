package com.topsuntech.gUnit_tjbz.gEU_system.utils;


/**
 * @author cuixb
 *
 */
public class UserOpRoleUtil {
	
	
//	public static 	HashMap<Long, UserOpRole> map = null;
//
//	public HashMap<Long, UserOpRole> getMap() {
//		return map;
//	}
//
//	public void setMap(HashMap<Long, UserOpRole> map) {
//		this.map = map;
//	}
//	
	

}
