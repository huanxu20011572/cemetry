package com.topsuntech.gUnit.gEU_taskFilter;

import javax.servlet.FilterConfig;
import javax.servlet.ServletRequest;

public interface TaskCallable {
	public void synCall(ServletRequest request, FilterConfig filterConfig);

	public void asynCall();
}
