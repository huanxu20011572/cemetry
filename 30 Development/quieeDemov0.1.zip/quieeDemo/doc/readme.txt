本工程为快逸报表的示例工程：

1. 报表文件位置： /web/reportFiles/ 中
2. 报表展示解析文件(JSP): /web/reportJsp/showReport.jsp
3. 数据源配置文件 /META-INF/context.xml

目前数据源未更改为项目的数据源Oracle版本，暂时无法直接运行。
后续会进行调整。