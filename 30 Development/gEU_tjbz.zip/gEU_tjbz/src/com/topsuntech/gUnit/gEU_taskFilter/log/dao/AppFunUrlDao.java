package com.topsuntech.gUnit.gEU_taskFilter.log.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.RowSet;

import com.topsuntech.gOS.query.DBRegistry;
import com.topsuntech.gOS.query.DBWrapper;
import com.topsuntech.gUnit.gEU_taskFilter.log.entity.AppFunUrl;

public class AppFunUrlDao {
	private static DBWrapper dbWrapper = DBRegistry.getDBWrapper("gos");

	public List findAppFunUrl(String url) throws SQLException {
		String sql = "select id, url, match_type, content_type from GOS_APPFUN_URL t where (t.MATCH_TYPE = 1 and ? like t.URL||'%') or (t.MATCH_TYPE = 2 and t.URL = ?)";
		RowSet rs = dbWrapper.executePreparedQuery(sql, new String[] { url, url });
		List l = new ArrayList();
		while (rs.next()) {
			AppFunUrl appFunUrl = new AppFunUrl();
			appFunUrl.setId(new Long(rs.getLong("id")));
			appFunUrl.setUrl(rs.getString("url"));
			appFunUrl.setMatchType(new Integer(rs.getInt("match_type")));
			Number contentType = (Number) rs.getObject("content_type");
			if (contentType != null) {
				appFunUrl.setContentType(new Integer(contentType.intValue()));
			}

			l.add(appFunUrl);
		}
		return l;
	}
}
