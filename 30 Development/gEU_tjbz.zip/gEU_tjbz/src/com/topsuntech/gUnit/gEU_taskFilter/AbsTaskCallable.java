package com.topsuntech.gUnit.gEU_taskFilter;

import javax.servlet.FilterConfig;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;

public abstract class AbsTaskCallable implements TaskCallable {
	protected String uri = null;

	protected String remoteAddr = null;

	protected String queryString = null;

	public void synCall(ServletRequest request, FilterConfig filterConfig) {
		HttpServletRequest req = ((HttpServletRequest) request);
		uri = req.getRequestURI();
		remoteAddr = req.getRemoteAddr();
		queryString = req.getQueryString();
	}
}
