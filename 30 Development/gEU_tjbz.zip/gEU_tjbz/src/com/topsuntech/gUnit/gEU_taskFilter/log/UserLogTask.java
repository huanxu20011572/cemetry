package com.topsuntech.gUnit.gEU_taskFilter.log;

import javax.servlet.FilterConfig;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;

import com.topsuntech.gOS.user.en.user.User;
import com.topsuntech.gOS.user.session.UserSession;
import com.topsuntech.gUnit.gEU_taskFilter.log.entity.AppFunUrl;
import com.topsuntech.gUnit.gEU_taskFilter.log.entity.LogRecord;

public class UserLogTask extends URLMatcherTask {

	private User user;

	public void synCall(ServletRequest request, FilterConfig filterConfig) {
		super.synCall(request, filterConfig);
		user = UserSession.getUser((HttpServletRequest) request);
	}

	protected void beforeSaveLogRecord(AppFunUrl appFunUrl, LogRecord record) {
		record.setUserType(new Integer(1));
		if (user != null) {
			record.setUserId(user.getId());
		}
	}
}
