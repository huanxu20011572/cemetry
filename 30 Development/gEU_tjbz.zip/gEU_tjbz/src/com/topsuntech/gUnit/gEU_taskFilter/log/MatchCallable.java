package com.topsuntech.gUnit.gEU_taskFilter.log;

import javax.servlet.FilterConfig;
import javax.servlet.ServletRequest;

import com.topsuntech.gUnit.gEU_taskFilter.log.entity.AppFunUrl;
import com.topsuntech.gUnit.gEU_taskFilter.log.entity.LogRecord;

public interface MatchCallable {
	public void synCall(ServletRequest request, FilterConfig filterConfig);

	public void asynCall(AppFunUrl appFunUrl, LogRecord record);
}
