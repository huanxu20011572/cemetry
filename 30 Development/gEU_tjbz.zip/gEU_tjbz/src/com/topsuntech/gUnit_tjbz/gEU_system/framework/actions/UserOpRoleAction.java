package com.topsuntech.gUnit_tjbz.gEU_system.framework.actions;

import com.topsuntech.gUnit.gEU_util.framework.actions.BaseAction;

/**
 * Ȩ�޿���
 * @author cuixb
 *
 */
public class UserOpRoleAction extends BaseAction{
	
	
	

}
