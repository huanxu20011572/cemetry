package com.topsuntech.gUnit.gEU_ssoImp;


import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.topsuntech.gOS.sso.ssoimpl.LoginState;
import com.topsuntech.gOS.user.en.user.User;

public class WebSPrvLoginStateImpl implements LoginState {

    public Object getLoginSendUserInfo(HttpServletRequest request, HttpServletResponse response, String trSiteMark) throws ServletException, IOException {
        String canumber = "";
        
        Object userObject = request.getSession().getAttribute("loginUser"); //sprvUserҪȷ��
        
        if(userObject != null){
            User user = (User) userObject;
            if(user != null){
//                canumber = SprvUser.getId() + "$tyfws"; //ֱ��ͨ��user����   
            	canumber = user.getCanumber();
            }
        }        
        
        return canumber;
    }

    public boolean isLogin(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        boolean bLogin = false;
        
        Object userObject = request.getSession().getAttribute("loginUser");        
        if(userObject != null){
            User user = (User) userObject;
            if(user != null){
                bLogin = true;
            }
        }
        
        return bLogin;
    }

}