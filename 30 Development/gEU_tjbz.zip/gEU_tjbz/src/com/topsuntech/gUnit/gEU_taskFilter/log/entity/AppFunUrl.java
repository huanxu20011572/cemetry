package com.topsuntech.gUnit.gEU_taskFilter.log.entity;

import java.io.Serializable;

public class AppFunUrl implements Serializable {

	private static final long serialVersionUID = -4811250335383743212L;

	private Long id;

	private String url;

	private Integer matchType;

	private Integer contentType;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Integer getMatchType() {
		return matchType;
	}

	public void setMatchType(Integer matchType) {
		this.matchType = matchType;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public Integer getContentType() {
		return contentType;
	}

	public void setContentType(Integer contentType) {
		this.contentType = contentType;
	}

}
