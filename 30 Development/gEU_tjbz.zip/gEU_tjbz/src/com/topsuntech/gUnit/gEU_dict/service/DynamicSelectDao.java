package com.topsuntech.gUnit.gEU_dict.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import net.sf.hibernate.Hibernate;
import net.sf.hibernate.type.Type;

import org.apache.struts.util.LabelValueBean;

import com.topsuntech.gOS.query.TSDBException;
import com.topsuntech.gUnit.common.web.util.DAOBase;
import com.topsuntech.gUnit.gEU_util.entity.SjRegion;

public class DynamicSelectDao extends DAOBase{

	public DynamicSelectDao(String schema) {
		super(schema);
		// TODO �Զ����ɹ��캯�����
	}
	public DynamicSelectDao() {
		super("gos");
		// TODO �Զ����ɹ��캯�����
	}
	public List queryBasicInfo(String parentRegionCode) throws TSDBException{
		List listP = new ArrayList();
		List listT = new ArrayList();
		StringBuffer queryHql = new StringBuffer("");		
		queryHql.append(" From SjRegion t where t.useFlag=1 and t.parentId=(select m.id From SjRegion m where m.regionCode=?)");
		listP.add(parentRegionCode);
		listT.add(Hibernate.STRING);
		Type[] types=(Type[])listT.toArray(new Type[0]);
		queryHql.append(" order by t.orderByItem ");
		return  query(queryHql.toString(),listP.toArray(),types);	
	}
	
	
	
	/**
	 * �������и��ڵ�
	 * @return List ������Ϣ
	 * @throws TSDBException
	 */
	public  List getRegionByParentIdImp(Long parentId)
			throws TSDBException {
		List listP = new ArrayList();
		List listT = new ArrayList();	
		StringBuffer querySql = new StringBuffer();
		querySql.append("from SjRegion r where r.useFlag=1 ");
		
		if (parentId != null){
			querySql.append(" and r.parentId=?");
			listP.add(parentId);
			listT.add(Hibernate.LONG);
		}
		querySql.append(" order by r.orderByItem");		
		List options= new ArrayList();
		Type[] types=(Type[])listT.toArray(new Type[0]);		
		List list=query(querySql.toString(),listP.toArray(),types);
		System.out.println("����"+list.size());
		for (Iterator iter = list.iterator(); iter.hasNext();) {
			SjRegion element = (SjRegion) iter.next();
			options.add(new LabelValueBean(element.getRegionCode(),element.getName()));
		}
		return options;
		
	}
	/**
	 * �ڵ�ֵ��ñ����ڵ������ӽڵ�
	 */
	public List queryChilerList(String regionCode) throws TSDBException{
		List listP = new ArrayList();
		List listT = new ArrayList();
		List options= new ArrayList();
		StringBuffer queryHql = new StringBuffer("");		
		queryHql.append(" From SjRegion t where t.useFlag=1 and t.parentId=(select m.parentId From SjRegion m where m.regionCode=?)");
		listP.add(regionCode);
		listT.add(Hibernate.STRING);
		Type[] types=(Type[])listT.toArray(new Type[0]);

		queryHql.append(" order by t.orderByItem ");

		
		List list= query(queryHql.toString(),listP.toArray(),types);
		for (Iterator iter = list.iterator(); iter.hasNext();) {
			SjRegion element = (SjRegion) iter.next();
			options.add(new LabelValueBean(element.getRegionCode(),element.getName()));
		}
		return options;
		
	}
	/**
	 * �������и��ڵ�
	 * @return List ������Ϣ
	 * @throws TSDBException
	 */
	public  List findRegionByList(String regionCode)
			throws TSDBException {
		StringBuffer querySql = new StringBuffer();
		querySql.append("From SjRegion t where t.useFlag=1 and t.parentId=(select m.parentId From SjRegion m where m.regionCode=?) ");
		querySql.append(" order by t.orderByItem  ");
		Object[] param =new Object[]{regionCode};
		Type[] types=new Type[]{Hibernate.STRING};;		
		List list=  query(querySql.toString(),param,types);
		List options= new ArrayList();
		for (Iterator iter = list.iterator(); iter.hasNext();) {
			SjRegion element = (SjRegion) iter.next();
			options.add(new LabelValueBean(element.getRegionCode(),element.getName()));
		}	
		return options;	
	}
	/**
	 * ���ݸ��ڵ��������ӽڵ�
	 * @param parentRegionCode
	 * @return
	 * @throws TSDBException
	 */
	
	public List queryBasicInfoChiler(String parentRegionCode) throws TSDBException{
		List listP = new ArrayList();
		List listT = new ArrayList();
		StringBuffer queryHql = new StringBuffer("");		
		queryHql.append(" From SjRegion t where t.useFlag=1 and t.parentId=(select m.id From SjRegion m where m.regionCode=?)");
		listP.add(parentRegionCode);
		listT.add(Hibernate.STRING);
		Type[] types=(Type[])listT.toArray(new Type[0]);
		queryHql.append(" order by t.orderByItem ");		
		List options= query(queryHql.toString(),listP.toArray(),types);	
		List labevalues=new ArrayList();
		for (Iterator iter = options.iterator(); iter.hasNext();) {
			SjRegion element = (SjRegion) iter.next();
			labevalues.add(new LabelValueBean(element.getRegionCode(),element.getName()));
		}
		return labevalues;
	}
	
	
	/**
	 * ���ݸ��ڵ�������ӽڵ�id
	 * @param parentRegionCode
	 * @return
	 * @throws TSDBException
	 */
	
	public List queryBasicInfoChilerByParent(String parentRegionCode) throws TSDBException{
		List listP = new ArrayList();
		List listT = new ArrayList();
		StringBuffer queryHql = new StringBuffer("");		
		queryHql.append(" From SjRegion t where t.useFlag=1 and t.parentId=(select m.id From SjRegion m where m.regionCode=?)");
		listP.add(parentRegionCode);
		listT.add(Hibernate.STRING);
		Type[] types=(Type[])listT.toArray(new Type[0]);
		queryHql.append(" order by t.orderByItem ");		
		List options= query(queryHql.toString(),listP.toArray(),types);	
		List labevalues=new ArrayList();
		for (Iterator iter = options.iterator(); iter.hasNext();) {
			SjRegion element = (SjRegion) iter.next();
			labevalues.add(new LabelValueBean(element.getId().toString(),element.getName()));
		}
		return labevalues;
	}
	
	public  SjRegion findByRegionCode(String regionCode)
	throws Exception {
		return (SjRegion)this.findByValue("regionCode",regionCode,SjRegion.class);

}

}
