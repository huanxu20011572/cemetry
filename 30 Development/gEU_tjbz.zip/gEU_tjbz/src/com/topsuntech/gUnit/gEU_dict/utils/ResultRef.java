package com.topsuntech.gUnit.gEU_dict.utils;

public final class ResultRef {
    /**
     * �����ɹ�
     */
    public final static int OPER_SUCCESS = 0;
    /**
     * ����ʧ��
     */
    public final static int OPER_FAILD = 1;
    /**
     * ���м�¼
     */
    public final static int OPER_HASRECORD = 2;
}
