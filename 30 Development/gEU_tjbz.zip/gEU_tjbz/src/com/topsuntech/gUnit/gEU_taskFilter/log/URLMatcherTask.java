package com.topsuntech.gUnit.gEU_taskFilter.log;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;

import com.topsuntech.gOS.query.TSDBException;
import com.topsuntech.gUnit.gEU_taskFilter.AbsTaskCallable;
import com.topsuntech.gUnit.gEU_taskFilter.log.dao.AppFunUrlDao;
import com.topsuntech.gUnit.gEU_taskFilter.log.dao.LogRecordDao;
import com.topsuntech.gUnit.gEU_taskFilter.log.entity.AppFunUrl;
import com.topsuntech.gUnit.gEU_taskFilter.log.entity.LogRecord;

public class URLMatcherTask extends AbsTaskCallable {
	public static final String MATCH_CALLABLE_CLASSNAMES_ATTR = "_MatchCallableClassNames";

	protected Date date;

	protected List matchCallables = null;

	public void synCall(ServletRequest request, FilterConfig filterConfig) {
		super.synCall(request, filterConfig);
		date = new Date();
		createAndCallMatchCallables(request, filterConfig);
	}

	private String[] getMatchCallableClassNames(ServletRequest request, FilterConfig filterConfig) {
		HttpServletRequest req = ((HttpServletRequest) request);
		ServletContext context = req.getSession().getServletContext();

		String[] matchCallableClassNames = (String[]) context.getAttribute(MATCH_CALLABLE_CLASSNAMES_ATTR);

		if (matchCallableClassNames == null) {
			String mCall = filterConfig.getInitParameter("matchCallables");

			if (mCall != null) {
				List mcl = new ArrayList();
				String[] mClassNames = mCall.trim().split(",");
				for (int i = 0; i < mClassNames.length; i++) {
					mClassNames[i] = mClassNames[i].replace('\n', ' ').replace('\r', ' ').trim();
					if (mClassNames[i].length() != 0) {
						mcl.add(mClassNames[i]);
					}
				}

				if (mcl.size() > 0) {
					matchCallableClassNames = (String[]) mcl.toArray(new String[0]);
					context.setAttribute(MATCH_CALLABLE_CLASSNAMES_ATTR, matchCallableClassNames);
				}
			}
		}
		return matchCallableClassNames;
	}

	protected void createAndCallMatchCallables(ServletRequest request, FilterConfig filterConfig) {
		String[] matchCallableClassNames = getMatchCallableClassNames(request, filterConfig);

		if (matchCallableClassNames != null) {
			matchCallables = new ArrayList();
			for (int i = 0; i < matchCallableClassNames.length; i++) {
				if (matchCallableClassNames[i].length() != 0) {
					try {
						MatchCallable matchCallable = (MatchCallable) Class.forName(matchCallableClassNames[i]).newInstance();
						matchCallable.synCall(request, filterConfig);
						matchCallables.add(matchCallable);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		}
	}

	public void asynCall() {
		List appFunUrls = matchUrL(uri, queryString);
		if (appFunUrls != null && appFunUrls.size() > 0) {
			doAsynCallWhenMatch(appFunUrls);
		} else {
			if (matchCallables != null) {
				matchCallables.clear();
				matchCallables = null;

				uri = null;
				remoteAddr = null;
				queryString = null;
			}
		}
	}

	protected List matchUrL(String uri, String queryString) {
		String qUrl = uri;
		if (queryString != null && queryString.length() != 0) {
			qUrl = qUrl + "?" + queryString;
		}
		try {
			return new AppFunUrlDao().findAppFunUrl(qUrl);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	protected LogRecord createLogRecord(AppFunUrl appFunUrl) {
		return new LogRecord();
	}

	protected void beforeSaveLogRecord(AppFunUrl appFunUrl, LogRecord record) {
	}

	protected void afterSaveLogRecord(AppFunUrl appFunUrl, LogRecord record) {
		for (int i = 0; matchCallables != null && i < matchCallables.size(); i++) {
			MatchCallable matchCallable = (MatchCallable) matchCallables.get(i);
			try {
				matchCallable.asynCall(appFunUrl, record);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	protected void doAsynCallWhenMatch(List appFunUrls) {
		LogRecordDao dao = new LogRecordDao();
		for (int i = 0; i < appFunUrls.size(); i++) {
			AppFunUrl appFunUrl = ((AppFunUrl) appFunUrls.get(i));
			LogRecord record = createLogRecord(appFunUrl);

			record.setFunUrlId(appFunUrl.getId());
			record.setAccessTime(date);
			record.setInetAddress(remoteAddr);

			try {
				beforeSaveLogRecord(appFunUrl, record);
				dao.save(record);
				afterSaveLogRecord(appFunUrl, record);
			} catch (TSDBException e) {
				e.printStackTrace();
			}
		}

	}

}
