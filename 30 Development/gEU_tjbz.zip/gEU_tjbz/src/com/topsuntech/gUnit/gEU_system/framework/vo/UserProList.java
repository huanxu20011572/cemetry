package com.topsuntech.gUnit.gEU_system.framework.vo;


public class UserProList {

    public String getStr1() {
		return str1;
	}

	public void setStr1(String str1) {
		this.str1 = str1;
	}

	public String getStr2() {
		return str2;
	}

	public void setStr2(String str2) {
		this.str2 = str2;
	}

	public String getStr3() {
		return Str3;
	}

	public void setStr3(String str3) {
		Str3 = str3;
	}

	public String str1;

    public String getStr5() {
		return Str5;
	}

	public void setStr5(String str5) {
		Str5 = str5;
	}

	public String str2;
    
    public String  Str3;

	public String Str4;
	//�������
	public String Str5;
	//�û�����
	public String userName;
	//������
	public String workDeptName;
	//������
	public String deptName;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getWorkDeptName() {
		return workDeptName;
	}

	public void setWorkDeptName(String workDeptName) {
		this.workDeptName = workDeptName;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getStr4() {
		return Str4;
	}

	public void setStr4(String str4) {
		Str4 = str4;
	}
    
    
}
